# Autoscript XrayColongan

## For Ubuntu 18.04 Only For First Time Installation (Update Repo) <br>
  
  ```html
 apt-get update && apt-get upgrade -y && apt dist-upgrade -y && update-grub && reboot
 ```

## Installation Link<br>

  ```html
sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update && apt install -y bzip2 gzip coreutils screen curl && wget https://raw.githubusercontent.com/Agunxzzz/XrayCol/main/vlu4a.sh && chmod +x vlu4a.sh && ./vlu4a.sh
  ```
script colongan dari https://github.com/Vlukss dan https://github.com/arismaramar/gif yang saya edit dikit
aslinya script bawaan ada fitur ssh, namun saya hapus karena memang ga idup websocketnya.

[ XRAY SERVICES ] <br>
<br>
✅ XRAY VMESS WEBSOCKET TLS & NON-TLS 443/80 MULTIPATH<br>
✅ XRAY VLESS WEBSOCKET TLS & NON-TLS 443/80<br>
✅ XRAY TROJAN WEBSOCKET TLS & NON-TLS 443/80<br>
✅ XRAY TROJAN TCP XTLS 443<br>
✅ XRAY TROJAN TCP TLS 443<br>
✅ TROJAN GO WS 8080<br>
<br>
Ga punya domain? PM ane aja :<a href="https://t.me/Tereza11" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br>
<br>
## GRATIS
